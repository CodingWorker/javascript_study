



window.onload = function () {
	
	var oButton = document.getElementById('button');
	addEvent(oButton, 'click', fn1);
	addEvent(oButton, 'click', fn1);
	addEvent(oButton, 'click', fn1);
	
};


function fn1(e) {
	alert('1');
}

function fn2(e) {
	alert('2');
}

function fn3(e) {
	alert('3');
}













