﻿<?php
	//echo 'www.ycku.com';
	print_r($_POST);
?>