



window.onload = function () {

	//$('#box').find('p').find('.a').css('color','red');
	
	$('#box div').css('color', 'red');
	
};















