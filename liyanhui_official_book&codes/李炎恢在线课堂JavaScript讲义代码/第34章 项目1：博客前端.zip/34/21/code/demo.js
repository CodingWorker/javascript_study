



/*
$(function () {
	
	var box = document.getElementById('box');
	
	
	setInterval(function () {
		box.style.left = getStyle(box, 'left') + 1 + 'px'
	}, 50);

	
	//alert(getStyle(box, 'left'));
	//box.style.left = 500 + 'px';
	
});
*/

$(function () {
	$('#box').animate('top', -5, 0, 50);
});



























