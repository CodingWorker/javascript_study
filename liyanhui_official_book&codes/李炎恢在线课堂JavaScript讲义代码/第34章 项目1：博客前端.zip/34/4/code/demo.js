




window.onload = function () {
	//$().getId('box').css('color', 'red');
	//$().getId('pox').css('color', 'blue');
	
	//$().getId('box').addClass('a').addClass('b').addClass('a');
	//$().getId('box').addClass('a').addClass('b').removeClass('a');
	
	
	//$().addRule(0, 'body', 'background:green', 0);
	
	$().removeRule(0).removeRule(0);
	
};
















