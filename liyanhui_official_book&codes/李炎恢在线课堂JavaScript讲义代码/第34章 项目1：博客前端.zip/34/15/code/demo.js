



window.onload = function () {


	//alert($().getId('box').html());
	//$().getTagName('span').css('color', 'red');
	//$().getClass('a').css('color', 'blue');
	
	//$('#box').css('color', 'red').click(function () {
	//	alert($(this).html());
	//});
	
	//$().getId('box').click(function () {
	//	$(this).css('color', 'green');
	//});
	
	//$('.a').css('color', 'red');
	
	//$('p').css('color', 'blue');
	
	//$('p').find('span').css('color', 'red');
	//$('span').css('color', 'red');
	//$('div').find('span').css('color', 'blue');
	
	//$('p').find('.a').css('color', 'red');
	
	//$('#q').css('color','red');
	
	//$('p').find('.a').css('color', 'red');

	
	//$('#box').css('color', 'red');
	
	//$('p').find('#q').css('color', 'red');
	
	//$('.a').css('color', 'red');
	
	//$('p').find('.a').css('color', 'red');
	
	
	$('div').find('span').css('color', 'blue');
	
};















