




window.onload = function () {
	//$().getId('box').html('pox').css('color', 'red');
	//alert($().getId('box').html());
	//$().getId('box').html('pox');
	//alert($().getId('box').css('color'));
	//alert($().getId('box').css('color', 'green'));
	//alert($().getId('box').css('fontSize'));
	//alert($().getId('box').css('color'));
	//alert($().getClass('red').elements.length);
	//$().getClass('red').css('color', 'red');
	//alert($().getClass('red').getElement(2).elements.length);
	//$().getClass('red').getElement(2).css('color', 'green');
	
	$().getClass('red').css('color', 'red');
};
















